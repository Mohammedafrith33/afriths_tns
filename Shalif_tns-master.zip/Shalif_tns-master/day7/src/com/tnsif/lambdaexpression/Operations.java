//Define FunctionalInterface Operations

package com.tnsif.lambdaexpression;

@FunctionalInterface
public interface Operations {
	float performArithmetic(int a, int b);
}
