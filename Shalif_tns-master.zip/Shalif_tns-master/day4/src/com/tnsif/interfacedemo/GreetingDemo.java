package com.tnsif.interfacedemo;

@FunctionalInterface
public interface GreetingDemo {
	void greet(); //used for declaration
	
}
